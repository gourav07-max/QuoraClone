package com.example.BusinessProfile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusinessProfileApplicationTests {

	@Test
	void contextLoads() {
	}

}
