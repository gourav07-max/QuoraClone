package com.example.BusinessProfile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BusinessProfileApplication {

	public static void main(String[] args) {
		SpringApplication.run(BusinessProfileApplication.class, args);
	}

}
